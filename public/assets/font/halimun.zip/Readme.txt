Hello,

Thank for downloading HALIMUN.
If there is a problem, question, or anything about my fonts, please sent an email to

pinegraphdsgn@gmail.com

How to Enable OpenType Features in Word, Photoshop and Illustrator

https://medialoot.com/blog/how-to-enable-opentype-features-in-word-photoshop-and-illustrator/

Thanks,


Creatype Studio